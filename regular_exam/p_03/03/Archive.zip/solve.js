// // TODO:
// function attachEvents() {
//     const BASE_URL = "http://localhost:3030/jsonstore/tasks/";
//     const loadBtn = document.getElementById("load-board-btn");
//     const todoTasks = document.querySelector("#todo-section .task-list");
//     const inProgressTasks = document.querySelector("#in-progress-section ul");
//     const codeReviewTasks = document.querySelector("#code-review-section ul");
//     const doneTasks = document.querySelector("#done-section ul");
//     const createTaskBtn = document.getElementById("create-task-btn");
//     const titleElement = document.getElementById("title");
//     const descriptionElement = document.getElementById("description");

//     function createCustomElement(
//         tag,
//         textContent = "",
//         attrs = {},
//         classes = []
//     ) {
//         const el = document.createElement(tag);

//         if (textContent) {
//             el.textContent = textContent;
//         }

//         if (attrs) {
//             for ([k, v] of Object.entries(attrs)) {
//                 el.setAttribute(k, v);
//             }
//         }

//         if (classes) {
//             for (const x of classes) {
//                 el.classList.add(x);
//             }
//         }
//         return el;
//     }

//     const listMapper = {
//         ToDo: todoTasks,
//         "In Progress": inProgressTasks,
//         "Code Review": codeReviewTasks,
//         Done: doneTasks,
//     };

//     const buttonMapper = {
//         ToDo: "Move to In Progress",
//         "In Progress": "Move to Code Review",
//         "Code Review": "Move to Done",
//         Done: "Close",
//     };

//     const updateStatusMapper = {
//         ToDo: "In Progress",
//         "In Progress": "Code Review",
//         "Code Review": "Done",
//     };

//     function getAllTasks() {
//         fetch(BASE_URL)
//             .then(res => res.json())
//             .then(data => {

//                 const lists = Object.values(listMapper);
//                 lists.forEach((x) => (x.innerHTML = ""));

//                 for (const x of Object.values(data)) {
//                     const list = listMapper[x.status];
//                     const liItems = createCustomElement(
//                         "li",
//                         (textContent = ""),
//                         (attrs = {}),
//                         (classes = ["task"])
//                     );
//                     const heading = createCustomElement(
//                         "h3",
//                         (textContent = x.title),
//                         (attrs = {}),
//                         (classes = [])
//                     );
//                     const desc = createCustomElement(
//                         "p",
//                         (textContent = x.description),
//                         (attrs = {}),
//                         (classes = [])
//                     );
//                     const btn = createCustomElement(
//                         "button",
//                         (textContent = buttonMapper[x.status]),
//                         (attrs = { id: x._id }),
//                         (classes = [])
//                     );
    
//                     if (x.status !== "Done") {
//                         btn.addEventListener("click", editBtnEvent);
//                     } else {
//                         btn.addEventListener("click", deleteBtnEvent);
//                     }
    
//                     liItems.appendChild(heading);
//                     liItems.appendChild(desc);
//                     liItems.appendChild(btn);
    
//                     list.appendChild(liItems);
//                 }
//             })
//             .catch(err => console.log(err));
//     }

//     function deleteRecord(id) {
//         const httpHeaders = {
//             method: "DELETE",
//         };

//         fetch(`${BASE_URL}${id}`, httpHeaders)
//             .then((res) => res.json())
//             .then(() => getAllTasks())
//             .catch((err) => console.log(err));
//     }

//     function createNewTaskEvent(e) {
//         e.preventDefault();
//         createNewTask();
//     }

//     function createNewTask() {
//         const title = titleElement.value;
//         const description = descriptionElement.value;
//         const status = "ToDo";

//         const data = {
//             title: title,
//             description: description,
//             status: status,
//         };

//         titleElement.value = "";
//         descriptionElement.value = "";

//         const httpHeaders = {
//             method: "POST",
//             headers: { "Content-type": "application/json" },
//             body: JSON.stringify(data),
//         };

//         fetch(BASE_URL, httpHeaders)
//             .then(res => res.json())
//             .then(() => getAllTasks())
//             .catch(err => console.log(err));
//     }

//     function loadTasksEvent(e) {
//         e.preventDefault();
//         getAllTasks();
//     }

//     function updateStatus(id) {
//         fetch(`${BASE_URL}${id}`)
//             .then((res) => res.json())
//             .then((data) => {
//                 const currentStatus = data.status;
//                 const newStatus = updateStatusMapper[currentStatus];

//                 const req = {
//                     status: newStatus,
//                 };

//                 const httpHeaders = {
//                     method: "PATCH",
//                     header: { "Content-type": "application/json" },
//                     body: JSON.stringify(req),
//                 };

//                 return fetch(`${BASE_URL}${id}`, httpHeaders);
//             })
//             .then((res) => res.json())
//             .then(() => getAllTasks())
//             .catch((err) => console.log(err));
//     }

//     function editBtnEvent(e) {
//         updateStatus(e.currentTarget.id);
//     }

//     function deleteBtnEvent(e) {
//         e.preventDefault();
//         deleteRecord(this.id);
//     }

//     createTaskBtn.addEventListener("click", createNewTaskEvent);
//     loadBtn.addEventListener("click", loadTasksEvent);
// }

// attachEvents();



function attachEvents() {
    const API_URL = 'http://localhost:3030/jsonstore/tasks/'
    const inputFields = {
        title: document.querySelector('#title'),
        description: document.querySelector('#description'),
    }

    const sprintApp = {
        toDo: document.querySelector('#todo-section ul'),
        inProgress: document.querySelector('#in-progress-section ul'),
        review: document.querySelector('#code-review-section ul'),
        done: document.querySelector('#done-section ul'),
        createBtn: document.querySelector('#create-task-btn'),
        loadBtn: document.querySelector('#load-board-btn'),
    }

    const board = {
        'ToDo': {
            html: sprintApp.toDo,
            btnText: 'Move to In Progress'
        },
        'In Progress': {
            html: sprintApp.inProgress,
            btnText: 'Move to Code Review'
        },
        'Code Review': {
            html: sprintApp.review,
            btnText: 'Move to Done'
        },
        'Done': {
            html: sprintApp.done,
            btnText: 'Close'
        },
    }

    const moveBtnStatus = {
        'Move to In Progress': 'In Progress',
        'Move to Code Review': 'Code Review',
        'Move to Done': 'Done',
    }

    const moveBtnFunctionality = async (even) => {

        const btnTextContent = even.currentTarget

        await apiRequest({
            url: `${API_URL}${btnTextContent.id}`,
            method: btnTextContent.textContent === 'Close' ? 'DELETE' : 'PATCH',
            item: {
                status: moveBtnStatus[btnTextContent.textContent]
            }
        })
        loadApiDataToHtml(await apiRequest({
            url: API_URL,
            method: 'GET'
        }))
    }

    const apiRequest = async ({url = '', method = '', id = '', item = ''}) => {
        const options = {
            method: method
        }
        if (['PATCH', 'POST'].includes(method)) {
            options.headers = {'Content-Type': 'application/json'}
            options.body = JSON.stringify(item)
        }
        const data = await fetch(`${url}${id}`, options)
        clearInputFields(Object.values(inputFields))
        return await data.json()
    }


    const clearInputFields = (dataFromInput => dataFromInput.forEach(x => x.value = ''))


    const createBtnFunctionality = async (event) => {
        await apiRequest({
            url: API_URL,
            method: 'POST',
            item: {
                title: inputFields.title.value,
                description: inputFields.description.value,
                status: 'ToDo'
            }
        })
        loadApiDataToHtml(await apiRequest({
            url: API_URL,
            method: 'GET'
        }))
    }

    const createHtmlTaskElement = (data) => {
        const li = document.createElement('li')
        li.classList.add('task');
        li.innerHTML =`<h3>${data.title}</h3><p>${data.description}</p><button id="${data._id}">${board[data.status].btnText}</button>`
        li.querySelector('button').addEventListener('click', moveBtnFunctionality)
        return li
    }

    const loadApiDataToHtml = (data) => {
        Object.values(board).forEach(x => x.html.innerHTML = '')
        Object.values(data).forEach(x => board[x.status].html.appendChild(createHtmlTaskElement(x)))
    }

    const loadBtnFunctionality = async (event) => {
        event.preventDefault()
        loadApiDataToHtml(await apiRequest({
            url: API_URL,
            method: 'GET'
        }))
    }

    sprintApp.createBtn.addEventListener('click', createBtnFunctionality)
    sprintApp.loadBtn.addEventListener('click', loadBtnFunctionality)

}

attachEvents();